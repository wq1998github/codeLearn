/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"

#include "bsp_led.h"
#include "bsp_uart.h"

void delay(uint32_t num)
{
    while (num--)
    {
        /* code */
    }
}

void vTaskLED(void *pvParameters)
{
    led_init();

    for (;;)
    {
        led_control(BSP_LED_ON);
        delay(0x7ffff);
        led_control(BSP_LED_OFF);
        delay(0x7ffff);
    }
}

void vTaskUart(void *pvParameters)
{
    uart1_init(115200);

    for (;;)
    {
        printf("Hello World\r\n");
        delay(0x8fffff);
    }
}

int main(void)
{

    BaseType_t xHandle = NULL;

    xHandle = xTaskCreate(vTaskLED, "LED", 1024, (void *)0, 1, NULL);
    xHandle = xTaskCreate(vTaskUart, "Uart", 1024, (void *)0, 1, NULL);

    (void)xHandle;

    vTaskStartScheduler();

    return 0;
}
